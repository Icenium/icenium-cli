(function (Accuracy) {
    Accuracy[Accuracy["ANY"] = 300] = "ANY";
    Accuracy[Accuracy["HIGH"] = 3] = "HIGH";
})(exports.Accuracy || (exports.Accuracy = {}));
var Accuracy = exports.Accuracy;

var Location = (function () {
    function Location() {
    }
    return Location;
})();
exports.Location = Location;

var LocationRegion = (function () {
    function LocationRegion() {
    }
    return LocationRegion;
})();
exports.LocationRegion = LocationRegion;
//# sourceMappingURL=location-types.js.map
