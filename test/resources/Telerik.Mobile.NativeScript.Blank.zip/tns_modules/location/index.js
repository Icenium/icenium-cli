module.exports = require("location/location");
//# sourceMappingURL=index.js.map
