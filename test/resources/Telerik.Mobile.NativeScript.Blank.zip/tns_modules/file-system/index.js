module.exports = require("file-system/file-system");
//# sourceMappingURL=index.js.map
