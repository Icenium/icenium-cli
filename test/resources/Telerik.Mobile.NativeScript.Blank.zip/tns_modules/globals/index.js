var timer = require("timer/timer");
var consoleModule = require("console/console");

setTimeout = timer.setTimeout;
clearTimeout = timer.clearTimeout;
setInterval = timer.setInterval;
clearInterval = timer.clearInterval;

console = new consoleModule.Console();
//# sourceMappingURL=index.js.map
