module.exports = require("application/application");
//# sourceMappingURL=index.js.map
