require("globals");

exports.onLaunch = undefined;

exports.onSuspend = undefined;

exports.onResume = undefined;

exports.onExit = undefined;

exports.onLowMemory = undefined;

exports.android = undefined;

exports.ios = undefined;
//# sourceMappingURL=application-common.js.map
