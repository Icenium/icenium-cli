module.exports = require("local-settings/local-settings");
//# sourceMappingURL=index.js.map
