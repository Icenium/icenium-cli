(function (CameraPosition) {
    CameraPosition[CameraPosition["FRONT"] = 0] = "FRONT";
    CameraPosition[CameraPosition["BACK"] = 1] = "BACK";
})(exports.CameraPosition || (exports.CameraPosition = {}));
var CameraPosition = exports.CameraPosition;

(function (FlashMode) {
    FlashMode[FlashMode["AUTO"] = 0] = "AUTO";
    FlashMode[FlashMode["ON"] = 1] = "ON";
    FlashMode[FlashMode["OFF"] = 2] = "OFF";
})(exports.FlashMode || (exports.FlashMode = {}));
var FlashMode = exports.FlashMode;
//# sourceMappingURL=camera-types.js.map
