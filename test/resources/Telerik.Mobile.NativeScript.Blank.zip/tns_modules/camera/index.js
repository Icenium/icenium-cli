module.exports = require("camera/camera");
//# sourceMappingURL=index.js.map
