module.exports = require("text/text");
//# sourceMappingURL=index.js.map
