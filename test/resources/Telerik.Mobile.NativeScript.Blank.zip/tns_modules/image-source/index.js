module.exports = require("image-source/image-source");
//# sourceMappingURL=index.js.map
