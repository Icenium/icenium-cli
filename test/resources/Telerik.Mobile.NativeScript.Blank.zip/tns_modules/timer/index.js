module.exports = require("timer/timer");
//# sourceMappingURL=index.js.map
