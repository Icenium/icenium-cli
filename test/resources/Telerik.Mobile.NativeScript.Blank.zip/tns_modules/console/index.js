module.exports = require("console/console");
//# sourceMappingURL=index.js.map
