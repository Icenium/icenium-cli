module.exports = require("promises/promises");
//# sourceMappingURL=index.js.map
